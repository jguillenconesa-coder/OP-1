# Pocket One 0.12.0 corresponding source

`Pocket-One/` contains the project; `JUCE/` contains the complete dependency source
at commit 51a8a6d7aeae7326956d747737ccf1575e61e209, including original notices.
No private Git history, compiler/SDK caches or credentials are included.

From this extracted directory, build without fetching JUCE again:

```sh
cmake -S Pocket-One -B build -DJUCE_PATH="$PWD/JUCE" -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
```

Windows Developer PowerShell:

```powershell
cmake -S Pocket-One -B build -A x64 -DJUCE_PATH="$PWD/JUCE"
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
./Pocket-One/packaging/windows/build-installer.ps1 -BuildDir build
```

Windows requires the normal Visual Studio C++ tools/Windows SDK; Linux requires
the development libraries documented in Pocket-One/README.en.md. NSIS 3.11+ is
needed to build a Windows installer. See Pocket-One/LICENSE, CREDITS.md and
THIRD_PARTY_NOTICES.md for licences/credits. Build/test infrastructure is supplied
alongside the source. The Windows cross-build helper is specific to /workspace;
native builds above work independently of the cloud helper layout.
