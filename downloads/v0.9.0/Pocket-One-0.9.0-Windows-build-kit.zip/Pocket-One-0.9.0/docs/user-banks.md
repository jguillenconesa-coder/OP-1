# Bancos de muestras del usuario

En **0.3.0**, pulsa **BROWSE → IMPORT BANK** y elige un ZIP Pocket One. En 0.2.2 el botón se llama BANK. Espera a que termine la importación con el transporte parado; los presets aparecen en la biblioteca bajo el nombre del banco. Puedes buscar, filtrar y separar variantes de muestras únicas. La biblioteca permanece en el equipo al cerrar y reabrir el plugin.

- Windows: `%APPDATA%\Pocket Instruments\Pocket One\Banks`.
- Las sesiones y proyectos del DAW incorporan la muestra o las 8/24 muestras del kit activo, junto con `sampleRoot`. Se pueden abrir sin instalar de nuevo el banco.
- Cargar un sonido mantiene el volumen de salida, el tempo, el patrón y el audio grabado en cinta.
- Las muestras estéreo se convierten a mono en este motor. La envolvente, el delay y el LFO son los de Pocket One; no se importan los algoritmos de efectos del OP-1.
- Un AIFF de sampler se reproduce como audio. No implica soporte para los presets de síntesis ni los slices de batería del OP-1.

## Crear un banco desde tus archivos

```sh
python3 scripts/build-user-bank.py --input /ruta/a/tus/muestras --output Mi-banco.zip
```

El generador lee WAV y AIFF/AIFF-C PCM, detecta duplicados por SHA256, conserva los nombres y divide WAVs largos en partes de hasta 16 segundos. Usa `base_freq` del APPL del OP-1 cuando existe, o la nota indicada en el nombre (por ejemplo, `A2`, `G3`, `F3`, `C4`). Sin esa información utiliza MIDI 60; no efectúa detección automática de afinación.

Produce un preset Dry por archivo/parte y un preset Space adicional por AIFF (delay y envolvente propios). El APPL original se conserva en el manifiesto como procedencia; sus valores no se presentan como una conversión exacta. También puede montar dos kits de ocho sonidos cuando se encuentran las muestras de campo correspondientes.

El ZIP contiene `bank.json` (versión 1), `samples/` y notas de uso. El importador limita tamaños, comprueba rutas y decodifica las muestras antes de mostrar los sonidos. Un banco inválido no debe dañar los bancos ya instalados. No se aceptan ejecutables ni se ejecuta código del ZIP.

## Colección aportada en esta sesión

Se han preparado **79 presets**, incluidos **dos kits**, usando **49 audios únicos** (25 AIFF y 24 WAV). Se eliminaron 24 duplicados. SOMMARNATT, AKTERSNURRAN y TYPISK MIDSOMMAR se dividieron para conservar todas sus partes: el banco contiene 52 archivos de audio.

Los AIFF declaran `type: sampler`, `synth_version: 3` y audio estéreo; son instrumentos muestreados, no patches numéricos para los motores FM/PHASE/STRING. Los nombres y metadatos completos están en el manifiesto del banco entregado. DRAGSPEL A2 se asigna a MIDI 45; DRAGSPEL G3 a 55; SKOGSFIOL F3 a 53 y C4 a 60.

El banco se ofrece ahora como [descarga directa del repositorio](../downloads/user-banks/README.md), después de que el enlace local del chat no permitiera descargarlo. No se etiqueta CC0: sus autores y condiciones de redistribución siguen pendientes de identificación. La infraestructura y los presets de parámetros propios sí forman parte del código público; el banco de fábrica original del proyecto sigue disponible con sus licencias.

En 0.3.0, [buttons-and-browser.md](buttons-and-browser.md) explica el navegador, favoritos, slots y el botón ADD SAMPLES.

## Kits ampliados de 0.5.0

El formato `formatVersion: 1` admite ahora un array `kit` de ocho **o 24** rutas de audio. Los bancos de ocho mantienen la asignación histórica. Un array opcional `pads` contiene hasta un objeto por muestra, con `start`, `end` (0–1), `gain` (0–2), `pitch` (-24–24 semitonos), `reverse` y `gated`. Campos omitidos usan sus valores por defecto; los valores se limitan al rango de los parámetros. Los elementos deben ser objetos y sus ajustes numéricos finitos o booleanos. No confundir `pads` con los ocho slots de selección de presets. [Guía del editor](kits.md).


## Purgar y reimportar (0.7.0)

En BROWSE, elige el banco importado en el filtro superior y pulsa **PURGE BANK**.
Confirma **DELETE FILES** para borrar sus carpetas y muestras instaladas de forma
permanente. Con **All banks**, se purgan todos los bancos importados. El botón
se desactiva cuando el filtro solo incluye sonidos integrados. Para purgar hay
que detener la cinta y la captura de entrada.

Se vacían los favoritos, slots y portapapeles de los sonidos eliminados; si el
sonido cargado pertenece al banco, se descargan su muestra/kit de RAM y sus
previews. La cinta grabada se conserva. Los WAV/AIFF originales, el ZIP de origen
y los sonidos de fábrica integrados se conservan. Los proyectos guardados
anteriormente contienen su propia copia de audio y pueden volver a cargarla;
la purga no reescribe esos archivos. Cierra otras instancias del plugin antes
de purgar: pueden conservar audio y catálogos en memoria.

Después usa **IMPORT BANK** para reinstalar el ZIP. La reimportación del mismo
manifiesto valida y decodifica una copia nueva antes de retirar las anteriores;
repara incluso archivos borrados o modificados y no acumula directorios de
bancos idénticos. Si Windows impide borrar algún archivo, el plugin muestra el
error; cierra otras instancias y repite la purga. Un manifiesto distinto puede
representar otro banco/variantes y no se elimina automáticamente por compartir
nombre.
