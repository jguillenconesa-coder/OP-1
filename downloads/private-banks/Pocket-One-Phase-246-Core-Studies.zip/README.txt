PHASE 246 CORE STUDIES — EXPERIMENTAL

Experimental oscillator-core renders, played by the Pocket One SAMPLER; not native Phase presets or recordings from an OP-1.
Raw stored control words are fed directly to the isolated Pd reconstruction; their original routing/scaling is not established.
Original ADSR, FX, LFO, octave behavior, original frequency preparation and full voice mixing are not applied.
Equal raw control sets intentionally share one audio asset; original presets with different FX/envelopes can sound alike here.
Host NCO at MIDI 60 / A4=440 Hz / 44100 Hz, source sine table, 6-second one-shots with a 10 ms tail fade.
The source sine matches firmware data; the apparent GNU parallel-copy timing discrepancy remains unresolved against hardware.