Pocket One 0.2.2+: click BANK, choose this ZIP, then select USER sounds.
Import while transport is stopped. The bank is stored locally; sessions embed their selected audio.
Original sample authors/license remain to be identified. This is not an official Teenage Engineering sound bank.
Sampler playback is mono (stereo is averaged). Original OP-1 engine/effect parameters are not imported. Dry/Space are Pocket One recipes. Long WAVs are split into <=16-second parts.
